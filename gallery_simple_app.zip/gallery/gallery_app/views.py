from django.shortcuts import render
from django.http import HttpResponse
from .models import GalleryContent


# Create your views here.
result = GalleryContent.objects.all()


def gallery_home(request):
    return render(
        request, "gallery_home.html", {"results": result, "base_title": "Gallery"}
    )


def gallery_detail(request, id):
    single_pic = next(item for item in result if item.pic_id == id)
    return render(request, "details_page.html", {"pic": single_pic})
