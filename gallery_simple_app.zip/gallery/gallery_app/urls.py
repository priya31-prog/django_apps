from django.urls import path
from . import views

app_name = "gallery"
urlpatterns = [
    path("gallery_home", views.gallery_home, name="gallery_home_page"),
    path("detail_page/<int:id>", views.gallery_detail, name="gallery_detail_page"),
]
