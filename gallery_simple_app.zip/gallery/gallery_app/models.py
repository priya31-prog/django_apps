from django.db import models

# Create your models here.


class GalleryContent(models.Model):
    pic_id = models.AutoField(primary_key=True)
    pic_name = models.CharField(max_length=100)
    created_time = models.TextField()
    description = models.TextField()
    cre_time = models.DateTimeField()
    image_url = models.URLField()

    class Meta:
        db_table = "gallery_content"
